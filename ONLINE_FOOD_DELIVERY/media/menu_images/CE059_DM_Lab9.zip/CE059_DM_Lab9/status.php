<?php

try{
    $dbhandler = new PDO('mysql:host=127.0.0.1;dbname=dm','root','');
    $dbhandler->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
} catch (Exception $ex) {
    echo "Connection failed";
    exit();
}
$fasta = $_POST["fasta"];
$sequence_information = explode("\n",$fasta);
$sequence = "";
for($j = 1;$j<sizeof($sequence_information);$j++){
    $sequence = $sequence."\n".$sequence_information[$j];
}
$regex_for_seqinfo= '/^(.*)$/m';
$regex_for_seq = '/^[A-Z\s]*$/m';
preg_match($regex_for_seqinfo, $sequence_information[0],$matches1);
preg_match($regex_for_seq, $sequence,$matches2);
$matched_seq_info=$matches1[0];
$matched_seq=$matches2[0];
if(empty($matched_seq_info) || empty($matched_seq)){
    echo "Please enter a valid Protein Sequence!";
    exit();
}
if(!empty($_POST["email"]))
    $email = md5($_POST["email"]);
else
    $email = "";
$comment = $_POST["comment"];
$feature = $_POST["feature"];
$sql="INSERT INTO feature_extraction (sequence_information,sequence,email,comment,feature) VALUES (?,?,?,?,?)";
try{
    $stmt = $dbhandler->prepare($sql);
    $stmt->bindValue(1, $sequence_information[0], PDO::PARAM_STR);
    $stmt->bindValue(2, $sequence, PDO::PARAM_STR);
    $stmt->bindValue(3, $email, PDO::PARAM_STR);
    $stmt->bindValue(4, $comment, PDO::PARAM_STR);
    $stmt->bindValue(5, $feature, PDO::PARAM_STR);
    $stmt->execute();
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>Status</title>
        </head>
        <body>
            <h1>Your job is submitted.Details are as follows:</h1>
            <h2>Job submitted so far:</h2>
            <?php
                $query = "SELECT * FROM feature_extraction";
                $stmt2 = $dbhandler->prepare($query);
                if($stmt2){
                    if($stmt2->execute()){
                        $result = $stmt2->fetchAll();
                        for($i=0;$i<sizeof($result);$i++){
                            $id = $result[$i]["fe_id"];
                            echo '<table style="border:1px solid black;margin-left:auto;margin-right:auto;" border="1px solid black">';
                            echo "<tr>";
                                echo "<td>";
                                    echo "ID:";
                                echo "</td>";
                                echo "<td>";
                                    echo $id;
                                echo "</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>";
                                    echo "Sequence\nInformation:";
                                echo "</td>";
                                echo "<td>";
                                    echo $result[$i]["sequence_information"];
                                echo "</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>";
                                    echo "Sequence:";
                                echo "</td>";
                                echo "<td>";
                                    echo $result[$i]["sequence"];
                                echo "</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>";
                                    echo "Email:";
                                echo "</td>";
                                echo "<td>";
                                    echo $result[$i]["email"];
                                echo "</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>";
                                    echo "Comment:";
                                echo "</td>";
                                echo "<td>";
                                    echo $result[$i]["comment"];
                                echo "</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>";
                                    echo "Feature\ntype:";
                                echo "</td>";
                                echo "<td>";
                                    echo $result[$i]["feature"];
                                echo "</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>";
                                    echo "Check result:";
                                echo "</td>";
                                echo "<td>";
                                    echo "<a href='result.php?id=$id'>Click</a>";
                                echo "</td>";
                            echo "</tr>";
                            echo '</table>';
                        }
                    }
                }
            ?>
        </body>
    </html>
<?php
} catch (Exception $ex) {
    echo "An exception was caught: ".$ex;
}
?>
