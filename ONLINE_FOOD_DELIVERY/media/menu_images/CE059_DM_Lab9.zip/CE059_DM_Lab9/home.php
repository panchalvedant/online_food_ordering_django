<?php
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Home Page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <form action="status.php" method="POST">
        <table style="border:1px solid black;margin-left:auto;margin-right:auto;" border="1px solid black">
            <tr>
                <th colspan="2">
                    Welcome, to Feature extraction for Protein Sequence(Fasta)
                </th>
            </tr>
            <tr>
                <td>
                    Protein Sequence(Fasta)*
                </td>
                <td>
                    <textarea name="fasta" rows="5" cols="100" required></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Email address(optional)
                </td>
                <td>
                    <input type="text" name="email">
                </td>
            </tr>
            <tr>
                <td>
                    Comment(optional)
                </td>
                <td>
                    <textarea name="comment" rows="2" cols="100"></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Select type of feature*
                </td>
                <td>
                    <br>
                    <input type="radio" name="feature" value="Length" checked="checked">Length
                    <br>
                    <input type="radio" name="feature" value="AAC">Amino Acid Count
                    <br>
                    <input type="radio" name="feature" value="NAAC">Normalized Amino Acid Count
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" value="Submit">
                </td>
            </tr>
        </table>
        </form>
    </body>
</html>