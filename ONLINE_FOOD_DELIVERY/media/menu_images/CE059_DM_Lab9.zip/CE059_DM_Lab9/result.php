<?php
$id = $_GET["id"];

try{
    $dbhandler = new PDO('mysql:host=127.0.0.1;dbname=dm','root','');
    $dbhandler->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
} catch (Exception $ex) {
    echo "Connection Failed!";
    exit();
}

$ans = array();
$chars = ['A','R','N','D','C','Q','E','G','H','I','L','K','M','F','P','S','T','W','Y','V'];
$ans = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
try{
    $sql="SELECT * FROM feature_extraction WHERE fe_id = ?";
    $stmt = $dbhandler->prepare($sql);
    $stmt->bindValue(1,$id);
    $stmt->execute();
    $result = $stmt->fetchAll();
    $sequence_information = $result[0]["sequence_information"];
    $sequence = $result[0]["sequence"];
    if($result[0]["feature"] == "AAC"){
        $length = strlen($sequence);
        for($i = 0; $i < $length; $i++) {
            for($j=0;$j<sizeof($chars);$j++){
                if($sequence[$i] == $chars[$j]){
                    $ans[$j]++;
                }
            }
        }
        echo "Amino acid count for your submitted sequence is as follows:";
        echo '<table style="border:" border="1px solid black">';
        for($i=0;$i<sizeof($chars);$i++){
            if($chars[$i]!='' && $chars[$i]!='\n'){
                echo '<tr>';
                    echo '<td>';
                        echo $chars[$i];
                    echo '</td>';
                    echo '<td>';
                        echo $ans[$i];
                    echo '</td>';
                echo '</tr>';
            }
        }
        echo '</table>';
    }
    else if($result[0]["feature"] == "NAAC"){
        $length = strlen($sequence);
        for($i = 0; $i < $length; $i++) {
            for($j=0;$j<sizeof($chars);$j++){
                if($sequence[$i] == $chars[$j]){
                    $ans[$j]++;
                }
            }
        }
        for($i=0;$i<sizeof($ans);$i++){
            $ans[$i] = $ans[$i] / $length * 100;
        }
        echo "Normalized amino acid count for your submitted sequence is as follows:";
        echo '<table style="border:" border="1px solid black">';
        for($i=0;$i<sizeof($chars);$i++){
            if($chars[$i]!='' && $chars[$i]!='\n'){
                echo '<tr>';
                    echo '<td>';
                        echo $chars[$i];
                    echo '</td>';
                    echo '<td>';
                        echo $ans[$i];
                    echo '</td>';
                echo '</tr>';
            }
        }
        echo '</table>';
    }
    else if($result[0]["feature"] == "Length"){
        $length = strlen($sequence);
        echo "The length of your submitted fasts is ". $length;
    }
} catch (Exception $ex) {
    echo "An exception was caught: ".$ex;
}
?>